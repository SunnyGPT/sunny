export const CHANNEL_OPTIONS = [
  { key: 1, text: 'OpenAI', value: 1, color: 'green' },
  { key: 8, text: '自定义', value: 8, color: 'pink' },
  { key: 3, text: 'Azure', value: 3, color: 'olive' },
  { key: 2, text: 'API2D', value: 2, color: 'blue' },
  { key: 4, text: 'CloseAI', value: 4, color: 'teal' },
  { key: 5, text: 'OpenAI-SB', value: 5, color: 'brown' },
  { key: 6, text: 'OpenAI Max', value: 6, color: 'violet' },
  { key: 7, text: 'OhMyGPT', value: 7, color: 'purple' },
  { key: 9, text: 'AI.LS', value: 9, color: 'yellow' },
  { key: 10, text: 'AI Proxy', value: 10, color: 'purple' },
  { key: 12, text: 'API2GPT', value: 12, color: 'blue' }
];